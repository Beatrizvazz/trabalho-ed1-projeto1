# Instruções para Entrega do Projeto

**Aluno:** Beatriz Cristina Vaz  
**Matrícula:** 202500560227

## Arquivo para Submissão

O arquivo `projeto_ed1_BeatrizCristinaVaz.zip` contém todo o projeto pronto para entrega.

## Conteúdo do Arquivo ZIP

O arquivo compactado contém a seguinte estrutura:

```
projeto_ed1/
├── LEIA-ME.txt                 (Matrícula e nome do aluno)
├── README.md                   (Documentação do projeto)
├── RELATORIO.md                (Relatório técnico)
└── src/                        (Código-fonte)
    ├── Makefile                (Arquivo de compilação)
    ├── *.c                     (Arquivos de implementação)
    └── *.h                     (Arquivos de cabeçalho)
```

## Verificação da Compilação

O projeto foi testado e compila corretamente com os seguintes comandos:

```bash
cd src
make
```

O executável `ted` é gerado no mesmo diretório `src/`.

## Estruturas de Dados Implementadas

Conforme solicitado no projeto, foram implementadas as seguintes estruturas:

### 1. Pilha (pilha.c / pilha.h)
- Utilizada para implementar os carregadores
- Operações: empilha, desempilha, topo, vazia
- Estrutura opaca (struct definida apenas no .c)

### 2. Fila (fila.c / fila.h)
- Utilizada para implementar a arena
- Operações: enfileira, desenfileira, início, vazia
- Estrutura opaca (struct definida apenas no .c)

### 3. Módulos Principais
- **Disparador** (disparador.c/h): Gerencia disparadores com 2 carregadores
- **Carregador** (carregador.c/h): Pilha de formas geométricas
- **Arena** (arena.c/h): Fila de formas lançadas para processamento

## Comandos Implementados

### Arquivo .qry

Todos os comandos especificados foram implementados:

- `pd l x y` - Posiciona disparador
- `lc c n` - Carrega n formas no carregador c
- `atch d cesq cdir` - Encaixa carregadores no disparador
- `shft d [e|d] n` - Pressiona botão esquerdo/direito n vezes
- `dsp d dx dy [v|i]` - Dispara forma com deslocamento
- `rjd d [e|d] dx dy ix iy` - Rajada de disparos
- `calc` - Processa formas na arena

## Observações Importantes

1. **Modularização**: Código bem modularizado com separação clara entre interface (.h) e implementação (.c)

2. **Structs Opacos**: Todas as estruturas de dados são opacas (não definidas nos arquivos .h)

3. **Flags de Compilação**: 
   - `-std=c99` (padrão C99)
   - `-fstack-protector-all` (proteção de pilha)

4. **Documentação**: Todos os arquivos .h estão bem documentados com comentários explicativos

5. **Gerenciamento de Memória**: Toda memória alocada é devidamente liberada

## Como Submeter

1. Faça o upload do arquivo `projeto_ed1_BeatrizCristinaVaz.zip` no Classroom

2. No campo de texto, insira a URL do repositório Git (se aplicável):
   ```
   BeatrizCristinaVaz https://github.com/[seu-usuario]/[seu-repositorio].git
   ```

## Checklist de Entrega

- [x] Arquivo LEIA-ME.txt com matrícula e nome
- [x] Código-fonte em diretório src/
- [x] Makefile funcional
- [x] Implementação de Pilha
- [x] Implementação de Fila
- [x] Structs não declarados em arquivos .h
- [x] Código compila sem erros
- [x] Flags de compilação corretas (-std=c99 -fstack-protector-all)
- [x] Código bem modularizado
- [x] Documentação adequada nos arquivos .h

## Contato

Em caso de dúvidas sobre a entrega, entre em contato através dos canais oficiais da disciplina.

